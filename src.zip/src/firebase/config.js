const firebaseConfig = {
  apiKey: "AIzaSyA_v1T8jOGjB1LSDU_CJLQkGYftAhdoDKw",
  authDomain: "login-fam.firebaseapp.com",
  projectId: "login-fam",
  storageBucket: "login-fam.appspot.com",
  messagingSenderId: "462773663524",
  appId: "1:462773663524:web:b72caf0dd8e937347625b1",
};

export default firebaseConfig;
