export const Status = {
  Married: "สมรส",
  Single: "โสด",
  Divorce: "หย่าร้าง",
};

export const Gender = {
  Male: "male",
  Female: "female",
};

export const MemberPosition = {
  Spouse: "คู่สมรส",
  Child: "บุตร",
};
